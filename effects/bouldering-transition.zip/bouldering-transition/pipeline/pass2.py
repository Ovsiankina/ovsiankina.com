import cv2, numpy as np, sys
sys.argv=['x']; exec(open('seg3.py').read().split("if __name__")[0])
plab=cv2.cvtColor(plate,cv2.COLOR_BGR2LAB).astype(np.float32)
pchroma=np.hypot(plab[...,1]-128,plab[...,2]-128)
pa,pb=plab[...,1]-128,plab[...,2]-128
I0,I1=100,1597; N=I1-I0
out=np.zeros((N,H,W//8),np.uint8)
def fill(m):
    ff=m.copy(); cv2.floodFill(ff,np.zeros((H+2,W+2),np.uint8),(0,0),1); return m|(1-ff)
K3=np.ones((3,3),np.uint8)
KB=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(25,25)); KN=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(31,31))
prev=None; prevlab=None; age=np.zeros((H,W),np.uint8)
for j,i in enumerate(range(I0,I1)):
    f,m,dist=seg(i)
    lab=cv2.cvtColor(f,cv2.COLOR_BGR2LAB).astype(np.float32)
    ratio=(lab[...,0]+1)/(plab[...,0]+1)
    fa,fb=lab[...,1]-128,lab[...,2]-128; fc=np.hypot(fa,fb)
    dch=np.hypot(fa-pa,fb-pb)
    cosang=(fa*pa+fb*pb)/(fc*pchroma+1e-3); cr=fc/(pchroma+1e-3)
    # shadows: grey wall darkened without a colour shift; coloured holds darkened along their own hue
    sh=(pchroma<12)&(ratio>0.5)&(ratio<0.99)&(dch<7)
    sh|=(pchroma>=12)&(ratio>0.2)&(ratio<0.99)&(cosang>0.93)&(cr>0.3)&(cr<1.2)
    # 1) clean core = the old pipeline (big blob + sizeable pieces)
    m2=cv2.morphologyEx((m.astype(bool)&~sh).astype(np.uint8),cv2.MORPH_OPEN,K3)
    n,lbl,st,_=cv2.connectedComponentsWithStats(m2)
    if n<=1 or st[1:,4].max()<150:
        out[j]=0; prev=None; age[:]=0; continue
    big=1+np.argmax(st[1:,4])
    core=np.isin(lbl,[k for k in range(1,n) if st[k,4]>=max(40,st[big,4]*0.03)]).astype(np.uint8)
    body=cv2.dilate(core,KB)
    # 2) small pieces near the body (feet cut off at a thin ankle) come back if they are real foreground
    for k in range(1,n):
        if core[lbl==k].any() or st[k,4]<18: continue
        pk=lbl==k
        if body[pk].mean()>0.5 and dist[pk].mean()>22: core[pk]=1
    # 3) geodesic growth through the weak mask, at most ~10 px from the core
    weak=((dist>9)&~sh).astype(np.uint8)
    g=core.copy()
    for _ in range(10): g=cv2.dilate(g,K3)&(weak|core)
    fin=g
    # 4) persistence: a still limb on a same-coloured hold stops differing from the plate but also stops changing
    if prev is not None:
        still=np.sqrt(((lab-prevlab)**2).sum(-1))<6
        near=cv2.dilate(fin,KN)
        carry=(prev>0)&(fin==0)&still&(near>0)&(age<45)
        age=np.where(carry,age+1,0).astype(np.uint8)
        fin=fin|carry.astype(np.uint8)
    fin=fill(fin)
    # filling closes loops between limbs and body; take the grey wall shadow back out of them
    grey=(pchroma<12)&(fc<8)&(ratio>0.45)&(dch<6)
    fin=(fin.astype(bool)&~grey).astype(np.uint8)
    fin=cv2.morphologyEx(fin,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
    n3,l3,s3,_=cv2.connectedComponentsWithStats(fin)
    if n3>1:
        b3=1+np.argmax(s3[1:,4]); fin=np.isin(l3,[k for k in range(1,n3) if s3[k,4]>=25]).astype(np.uint8)
    out[j]=np.packbits(fin.astype(bool),axis=1)
    prev=fin; prevlab=lab
    if j%300==0: print(j,flush=True)
np.save('mask_new.npy',out)
