import cv2, numpy as np, onnxruntime as ort, time
from scipy.ndimage import median_filter
W,H=960,540; N=1650; I0=100
fr=np.memmap('frames960.raw',dtype=np.uint8,mode='r',shape=(N,H,W,3))
A=np.load('affines.npy'); A=median_filter(A,size=(5,1,1),mode='nearest')
F=np.load('mask_final.npy')
sess=ort.InferenceSession('../models/u2net_human_seg.onnx',providers=['CPUExecutionProvider'])
MEAN=np.array([0.485,0.456,0.406]); STD=np.array([0.229,0.224,0.225])
def aligned(j): return cv2.warpAffine(np.asarray(fr[j+I0]),A[j+I0],(W,H),borderMode=cv2.BORDER_REPLICATE)
def person(j, f=None, m=None):
    f=aligned(j) if f is None else f
    m=np.unpackbits(F[j],axis=1)[:,:W] if m is None else m
    ys,xs=np.nonzero(m)
    if len(xs)<50: return np.zeros((H,W),np.float32), None
    cx,cy=(xs.min()+xs.max())/2,(ys.min()+ys.max())/2
    side=max(xs.max()-xs.min(),ys.max()-ys.min())*1.35+40
    x0,y0=int(cx-side/2),int(cy-side/2); s=int(side)
    pad=cv2.copyMakeBorder(f,s,s,s,s,cv2.BORDER_REPLICATE)
    crop=pad[y0+s:y0+2*s,x0+s:x0+2*s]
    im=cv2.resize(crop,(320,320),interpolation=cv2.INTER_AREA)[...,::-1].astype(np.float32)/255
    im=((im/max(im.max(),1e-6))-MEAN)/STD
    out=sess.run(None,{'input.1':im.transpose(2,0,1)[None].astype(np.float32)})[0][0,0]
    out=(out-out.min())/(out.max()-out.min()+1e-6)
    full=np.zeros((H+2*s,W+2*s),np.float32)
    full[y0+s:y0+2*s,x0+s:x0+2*s]=cv2.resize(out,(s,s),interpolation=cv2.INTER_LINEAR)
    return full[s:s+H,s:s+W], (x0,y0,s)
if __name__=='__main__':
    rows=[]
    for j in [1300,1340,1380,1460,1490,432]:
        t=time.time(); p,box=person(j); dt=time.time()-t
        f=aligned(j); m=np.unpackbits(F[j],axis=1)[:,:W].astype(bool)
        x0,y0,s=box; x0=max(0,x0); y0=max(0,y0); x1=min(W,x0+s); y1=min(H,y0+s)
        a=f.copy(); a[~m]=255
        b=f.copy(); b[p<0.5]=255
        heat=cv2.applyColorMap((p*255).astype(np.uint8),cv2.COLORMAP_JET)
        tiles=[cv2.resize(t[y0:y1,x0:x1],(240,240)) for t in (f,a,b,heat)]
        r=np.hstack(tiles); cv2.putText(r,f'{j} {dt:.2f}s',(4,16),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,0,255),1); rows.append(r)
    cv2.imwrite('u2test.jpg',np.vstack(rows))
