import numpy as np, cv2, sys
sys.argv=sys.argv[:2]
start=int(sys.argv[1])
exec(open('u2.py').read().split("if __name__")[0])
n=F.shape[0]
P=np.load('ml_prob.npy',mmap_mode='r+')
done=np.zeros(n,bool); done[:start]=True
for j in list(range(start,n,2))+[n-1]:
    p,_=person(j)
    P[j]=(cv2.resize(p,(W//2,H//2),interpolation=cv2.INTER_AREA)*255).astype(np.uint8); done[j]=True
    if j%100==0: print(j,flush=True)
for j in range(n):
    if not done[j]:
        P[j]=((P[j-1].astype(np.uint16)+P[j+1].astype(np.uint16))//2).astype(np.uint8)
P.flush(); print('done',flush=True)
