import cv2, numpy as np
pl=cv2.imread('plate2.png'); H,W=pl.shape[:2]
lab=cv2.cvtColor(pl,cv2.COLOR_BGR2LAB).astype(np.float32)
L=lab[...,0]; ch=np.hypot(lab[...,1]-128,lab[...,2]-128)
# the wall is the brightest thing around: a blurred local max follows its lighting without volumes dragging it down
wallL=cv2.GaussianBlur(cv2.dilate(L,np.ones((61,61),np.uint8)),(0,0),25)-8
roi=np.zeros((H,W),np.uint8); roi[:462,:866]=1; roi[:12,720:]=0   # dark ceiling strip, top right only
m=((ch>13)|(L<wallL-35)).astype(np.uint8)&roi
m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(9,9)))
def fill(x):
    ff=x.copy(); cv2.floodFill(ff,np.zeros((H+2,W+2),np.uint8),(480,500),1); return x|(1-ff)
m=fill(m)&roi
n,lbl,st,_=cv2.connectedComponentsWithStats(m)
keep=[k for k in range(1,n) if st[k,4]>=45]
out=np.zeros((H,W),np.int32)
for k in keep: out[lbl==k]=k
def hull_of(mask):
    cnts,_=cv2.findContours(mask.astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    hm=np.zeros((H,W),np.uint8); cv2.fillPoly(hm,[cv2.convexHull(np.vstack(cnts))],1); return hm>0
# 1) every hold: close its own outline (size-scaled) and fill holes; compact holds get their convex hull (chalk/highlight bites)
for k in keep:
    pk=(lbl==k).astype(np.uint8); a=st[k,4]
    r=int(np.clip(0.1*np.sqrt(a),2,6))
    pc=cv2.morphologyEx(pk,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*r+1,2*r+1)))
    cnts,_=cv2.findContours(pc,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE); cv2.drawContours(pc,cnts,-1,1,thickness=cv2.FILLED)
    out[(pc>0)&(out==0)&(roi>0)]=k
# 2) black volumes: glossy faces read as grey and drop out; the hull of the nearby dark pieces brings the face back
dk=((ch<13)&(L<110)&(roi>0)).astype(np.uint8)  # genuinely black volumes only
dk=cv2.morphologyEx(dk,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
grp=cv2.morphologyEx(dk,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(31,31)))
ng,lg,sg,_=cv2.connectedComponentsWithStats(grp)
for g in range(1,ng):
    pieces=(lg==g)&(dk>0)
    if pieces.sum()<900: continue
    hm=hull_of(pieces)
    ratio=hm.sum()/pieces.sum()
    gap=hm&~pieces
    wallfrac=((L>wallL-10)&(ch<9))[gap].mean() if gap.any() else 0
    print('group',sg[g,:4],'ratio',round(ratio,2),'wallfrac',round(float(wallfrac),2))
    if ratio>2.5 or wallfrac>0.3: continue
    owner=np.bincount(out[pieces].ravel()); owner[0]=0; k=int(owner.argmax())
    if k==0: continue
    # only take over wall-ish pixels (never steal another hold)
    out[hm&(out==0)&(roi>0)]=k
# peel bare-wall halos (shadow rims, closing bridges) off the outside of each hold, keep enclosed highlights
walllike=((ch<7)&(L>wallL-35))|((ch<10)&(L>150))   # bare wall, and white volumes (grey noise once dithered)
for _ in range(40):
    occ=(out>0).astype(np.uint8)
    edge=(occ>0)&(cv2.erode(occ,np.ones((3,3),np.uint8))==0)
    peel=edge&walllike
    if not peel.any(): break
    out[peel]=0
# hull fill per colour part (chromatic / dark), per connected piece: closes chalk bites and glossy faces
# without bridging the wall between two different holds
for k in np.unique(out[out>0]):
    pk=(out==k)
    for part in (pk&(ch>=14), pk&(ch<14)&(L<120)):
        pp=cv2.morphologyEx(part.astype(np.uint8),cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)))
        nq,lq,sq,_=cv2.connectedComponentsWithStats(pp)
        for q in range(1,nq):
            a=sq[q,4]
            if a<60: continue
            hm=hull_of(lq==q)
            if hm.sum()<=a*1.45: out[hm&(out==0)&(roi>0)&~((L>wallL-14)&(ch<6))]=k
# the start hold is white with a purple rim: rebuild it from the hull of its rim (and the purple hold under it)
sx0,sx1,sy0,sy1=452,505,312,392
sub=np.zeros((H,W),bool); sub[sy0:sy1,sx0:sx1]=True
hsv=cv2.cvtColor(pl,cv2.COLOR_BGR2HSV)
rim=sub&(hsv[...,0]>=125)&(hsv[...,0]<=165)&(hsv[...,1]>=25)
top=rim.copy(); top[352:,:]=False; bot=rim.copy(); bot[:350,:]=False
sk=int(np.bincount(out[rim].ravel(),minlength=2)[1:].argmax())+1 if (out[rim]>0).any() else int(out.max())+1
for part in (top,bot):
    if part.sum()>30: out[hull_of(part)&(roi>0)]=sk
START_LABEL=sk
# keep what matters: holds on the route (touched by the climber), plus only the big ones off to the sides
U=np.load('union.npy').astype(np.uint8)
Ud=cv2.dilate(U,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(13,13)))>0
nP,lP,sP,_=cv2.connectedComponentsWithStats((out>0).astype(np.uint8),connectivity=8)
dropped=0
for q in range(1,nP):
    pq=lP==q; a=sP[q,4]
    touched=(pq&Ud).sum()>=15 or (out[pq]==START_LABEL).any()
    grey=np.median(ch[pq])<10 and np.median(L[pq])>110
    big=a>=2500 and not grey
    if not (touched or big): out[pq]=0; dropped+=1; continue
    if not touched:
        # side holds: no grey wall/shadow bits, no thin cracks
        keepq=pq&~((ch<10)&(L>110)) if np.median(ch[pq])<14 else pq.copy()
        keepq=cv2.morphologyEx(keepq.astype(np.uint8),cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)))>0
        out[pq&~keepq]=0
        if keepq.sum()<1500: out[keepq]=0; dropped+=1
print('dropped pieces',dropped)
# local patch 1: the three stacked triangular volumes, top-left. Chalk and the red holds on them split their black
# faces, so rebuild each face as the hull of its own dark pixels (the middle and bottom faces touch: split at the white edge)
reg=np.zeros((H,W),bool); reg[45:150,0:125]=True
dkf=reg&(L<125)&(ch<16)&(roi>0)
dkf=cv2.morphologyEx(dkf.astype(np.uint8),cv2.MORPH_OPEN,np.ones((2,2),np.uint8))>0
yy,xx=np.mgrid[0:H,0:W]
faces=[dkf&(yy<88)&(xx>=60), dkf&(yy>=82)&(yy<=116)&(xx>=25), dkf&(yy>=118)&(xx>=10)]
for fm in faces:
    nT,lT,sT,_=cv2.connectedComponentsWithStats(fm.astype(np.uint8))
    if nT<2: continue
    big=1+np.argmax(sT[1:,4]); fm=lT==big
    if fm.sum()<150: continue
    hm=hull_of(fm)
    own=np.bincount(out[fm].ravel(),minlength=2); own[0]=0
    k=int(own.argmax()) if own.max()>0 else int(out.max())+1
    out[hm&(roi>0)&(out==0)]=k
# local patch 1b: the top triangle must match its two siblings: full outline (traced on the plate) and their dark face colour
tri=np.array([(63,59),(86,63),(98,66),(101,80),(106,93),(112,104),(121,117),(110,112),(96,103),(81,93),(68,85),(64,75)],np.int32)
tm=np.zeros((H,W),np.uint8); cv2.fillPoly(tm,[tri],1); tm=tm>0
own=np.bincount(out[tm].ravel(),minlength=2); own[0]=0
kt=int(own.argmax()) if own.max()>0 else int(out.max())+1
red=tm&(ch>=14)                                  # the red holds bolted on it keep their colour
out[tm&~red&((out==0)|(out==kt))]=kt
sib=(faces[1]|faces[2])
sib_col=np.median(pl[sib],axis=0)
face=tm&~red
dev=pl[face].astype(np.float32)-np.median(pl[face],axis=0)
pl=pl.copy(); pl[face]=np.clip(sib_col+dev*0.4,0,255).astype(np.uint8)
L=cv2.cvtColor(pl,cv2.COLOR_BGR2LAB)[...,0].astype(np.float32)
# local patch 2: the grey ring jugs at the top of the route (grabbed at the end), dropped earlier as grey wall
reg=np.zeros((H,W),bool); reg[0:80,430:560]=True
ring=(reg&(L<wallL-28)&(ch<16)&(roi>0)).astype(np.uint8)
ring=cv2.morphologyEx(ring,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
nR,lR,sR,_=cv2.connectedComponentsWithStats(ring)
for q in range(1,nR):
    if sR[q,4]<40: continue
    hq=hull_of(lR==q)&(out==0)
    out[hq]=int(out.max())+1   # solid: the ring's hole doesn't matter
    pl=pl.copy(); pl[hq]=(pl[hq].astype(np.float32)*0.78).astype(np.uint8)   # a touch darker so the grey ring reads on white
# local patch 3: the tiny grey hold grabbed above the purple hex (left of the route's top), lost as a bolt hole.
# draw it a bit bigger and darker than in the photo so it reads once dithered; fill the purple hex below it solid
gy,gx,gr=48,371,6
disc=np.zeros((H,W),np.uint8); cv2.circle(disc,(gx,gy),gr,1,-1); disc=disc>0
kg=int(out.max())+1; out[disc]=kg
hexs=np.zeros((H,W),bool); hexs[86:106,380:400]=True; hexs&=(ch>=14)
route_purple=np.median(pl[hexs],axis=0) if hexs.any() else np.array([120,55,100])
pl=pl.copy(); pl[disc]=np.clip(route_purple*0.3+np.array([175,70,140])*0.7,0,255).astype(np.uint8)   # route purple, lifted so it survives dithering at this size
pl[(np.hypot(*np.mgrid[0:H,0:W][::-1].__array__().reshape(2,H,W)-np.array([gx,gy])[:,None,None]) if False else disc)]=pl[disc]
hexm=np.zeros((H,W),bool); hexm[84:108,378:402]=True
hexp=hexm&(((ch>=14)&(L<200))|(L<150))
if hexp.sum()>20:
    hm=hull_of(hexp)
    kh=np.bincount(out[hexp].ravel(),minlength=2); kh[0]=0
    kh=int(kh.argmax()) if kh.max()>0 else int(out.max())+1
    out[hm&((out==0)|(out==kh))]=kh
# the start hold's body is white: tint it lilac (keeping its shading) so it reads against the white wall
st_m=(out==START_LABEL)&((ch<14)&(L>120))&sub
lilac=np.array([224,150,190],np.float32)   # BGR
shade=(L[st_m]/255.0)[:,None]
pl=pl.copy(); pl[st_m]=np.clip(lilac*np.clip(shade*1.12,0,1.15),0,255).astype(np.uint8)
# reveal order and pack
labels=[int(k) for k in np.unique(out[out>0])]   # every hold, including ones added by the local patches
ys={k:np.nonzero(out==k)[0].max() for k in labels}
rng=np.random.default_rng(3)
order=sorted(labels,key=lambda k:-(ys[k])+rng.uniform(-60,60))
idx=np.zeros((H,W),np.uint8)
for r,k in enumerate(order): idx[out==k]=r+1
# purple holds read too grey once dithered: +50% saturation on purple hues only (OpenCV hue ~128..165), holds only
hsv=cv2.cvtColor(pl,cv2.COLOR_BGR2HSV).astype(np.float32)
hh=hsv[...,0]
w=np.clip((hh-128)/6,0,1)*np.clip((165-hh)/7,0,1)*(idx>0)
hsv[...,1]=np.clip(hsv[...,1]*(1+0.5*w),0,255)
pl_boost=cv2.cvtColor(hsv.astype(np.uint8),cv2.COLOR_HSV2BGR)
pl_out=np.where((w>0)[...,None],pl_boost,pl)
OW,OH=640,360
rgb=cv2.resize(pl_out,(OW,OH),interpolation=cv2.INTER_AREA)
si=cv2.resize(idx,(OW,OH),interpolation=cv2.INTER_NEAREST)
rgb[si==0]=255
cv2.imwrite('holds_pack.png',np.vstack([rgb,cv2.cvtColor(si,cv2.COLOR_GRAY2BGR)]))
prev=np.full_like(pl,255); prev[idx>0]=pl_out[idx>0]
old=cv2.imread('holds_prev.png'); old=cv2.resize(old,(W,H),interpolation=cv2.INTER_NEAREST)
cv2.imwrite('holds_cmp.png',np.vstack([old,prev]))
print(len(order),'holds')
