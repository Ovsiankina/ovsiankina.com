import numpy as np, re, json
src="font/pilowlava3D-master/sources/PILOWLAVA 3D_basich latin western_obj.obj"
V=[]; objs={}; cur=None
for line in open(src,encoding='utf-8',errors='replace'):
    if line.startswith('v '): V.append([float(x) for x in line.split()[1:4]])
    elif line.startswith('o '): cur=line[2:].strip(); objs[cur]=[]
    elif line.startswith('f '): objs[cur].append([int(t.split('/')[0]) for t in line.split()[1:]])
V=np.array(V)
names=[n for n in objs if re.match(r'pilowlava_(c\d|l|i|m\d|b\d|n\d|g\d)_',n)]
for n in names:
    F=objs[n]; idx=np.unique([i for f in F for i in f])-1; P=V[idx]
    from collections import Counter
    print(n, len(F), Counter(len(f) for f in F), np.round(P.min(0),1), np.round(P.max(0),1))

def catmull_clark(P, F):
    P=np.asarray(P,float); nV=len(P)
    fp=np.array([P[f].mean(0) for f in F])
    edges={}
    for fi,f in enumerate(F):
        for k in range(len(f)):
            a,b=f[k],f[(k+1)%len(f)]; key=(min(a,b),max(a,b))
            edges.setdefault(key,[]).append(fi)
    ekeys=list(edges); eidx={e:i for i,e in enumerate(ekeys)}
    ep=np.zeros((len(ekeys),3)); boundary=np.zeros(len(ekeys),bool)
    for i,(a,b) in enumerate(ekeys):
        fs=edges[(a,b)]
        if len(fs)==2: ep[i]=(P[a]+P[b]+fp[fs[0]]+fp[fs[1]])/4
        else: ep[i]=(P[a]+P[b])/2; boundary[i]=True
    # vertex points
    vf=[[] for _ in range(nV)]; ve=[[] for _ in range(nV)]
    for fi,f in enumerate(F):
        for v in f: vf[v].append(fi)
    for i,(a,b) in enumerate(ekeys): ve[a].append(i); ve[b].append(i)
    NP=P.copy()
    for v in range(nV):
        if not vf[v]: continue
        be=[e for e in ve[v] if boundary[e]]
        if be:
            mids=[(P[ekeys[e][0]]+P[ekeys[e][1]])/2 for e in be]
            NP[v]=(P[v]*2+sum(mids[:2]) )/ (2+len(mids[:2])) if len(mids)>=2 else P[v]
            continue
        n=len(vf[v]); Fm=fp[vf[v]].mean(0)
        R=np.mean([(P[ekeys[e][0]]+P[ekeys[e][1]])/2 for e in ve[v]],0)
        NP[v]=(Fm+2*R+(n-3)*P[v])/n
    allP=np.vstack([NP,ep,fp]); eo=nV; fo=nV+len(ekeys)
    NF=[]
    for fi,f in enumerate(F):
        m=len(f)
        for k in range(m):
            v=f[k]; en=eidx[(min(v,f[(k+1)%m]),max(v,f[(k+1)%m]))]; epv=eidx[(min(v,f[k-1]),max(v,f[k-1]))]
            NF.append([v,eo+en,fo+fi,eo+epv])
    return allP,NF

def glyph(name, levels):
    F=objs[name]; idx=np.unique([i for f in F for i in f])-1
    remap={o+1:n for n,o in enumerate(idx)}
    P=V[idx]; FF=[[remap[i] for i in f] for f in F]
    for _ in range(levels): P,FF=catmull_clark(P,FF)
    tris=[]
    for f in FF:
        for k in range(1,len(f)-1): tris.append([f[0],f[k],f[k+1]])
    return P,np.array(tris)
