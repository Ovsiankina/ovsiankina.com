import numpy as np, cv2, sys
sys.argv=['x']; exec(open('volfix.py').read().split("\nif __name__=='__main__':")[0])
Mb=np.unpackbits(np.load('mask_ml_t.npy'),axis=2)[:,:,:W].astype(bool)
J0,J1=120,740
G=np.zeros((J1-J0,y1-y0,x1-x0),bool)
for i,j in enumerate(range(J0,J1)):
    _,g=volume_mask(j)
    n,l,s,_=cv2.connectedComponentsWithStats(g.astype(np.uint8))
    G[i]=np.isin(l,[k for k in range(1,n) if s[k,4]>=20])
    if j%100==0: print(j,flush=True)
# temporal: fill 1-frame gaps, then majority of 5
n=len(G); pad=np.concatenate([G[:1].repeat(2,0),G,G[-1:].repeat(2,0)])
C=G|((pad[1:n+1]|pad[0:n])&(pad[3:n+3]|pad[4:n+4]))
Kw=5   # 11-frame majority: a resting foot keeps one outline
cp=np.concatenate([C[:1].repeat(Kw,0),C,C[-1:].repeat(Kw,0)])
S=sum(cp[k:k+n].astype(np.uint8) for k in range(2*Kw+1))>=Kw+1
M2=Mb.copy(); M2[J0:J1,y0:y1,x0:x1]=S
np.save('mask_vol.npy',np.packbits(M2,axis=2))
def jitter(X):
    A=X[J0:J1,y0:y1,x0:x1].reshape(J1-J0,-1).sum(1).astype(float); d=np.abs(np.diff(A)); rel=d/np.maximum(A[1:],1)
    return round(d.mean(),1), int((rel>0.25).sum())
print('jitter before',jitter(Mb),'after',jitter(M2))
