import cv2, numpy as np, sys
sys.argv=['x']; exec(open('seg3.py').read().split("if __name__")[0])
I0=100
y0,y1,x0,x1=230,460,140,350
F0=np.load('mask_old.npy')            # plain classical masks: no carried-over ghosts
P=np.load('ml_prob.npy',mmap_mode='r')
K3=np.ones((3,3),np.uint8)
_pl=cv2.cvtColor(plate,cv2.COLOR_BGR2LAB).astype(np.float32); PLv=_pl[...,0]; _pc=np.hypot(_pl[...,1]-128,_pl[...,2]-128)
darkP=(PLv<120)&(_pc<14); _pa,_pb=_pl[...,1]-128,_pl[...,2]-128
def volume_mask(j, T=7, steps=20):
    f,_,dist=seg(j+I0)
    m=np.unpackbits(F0[j],axis=1)[:,:W].astype(bool)
    p=cv2.resize(P[j],(W,H),interpolation=cv2.INTER_LINEAR).astype(np.float32)/255
    Lf=cv2.cvtColor(f,cv2.COLOR_BGR2LAB)[...,0]
    # only on the black volume, and only pixels that got LIGHTER than the empty volume (a shoe); shadows get darker
    Lff=Lf.astype(np.float32)
    # from the ankle, take anything on the black volume that changed: lighter (grey shoe) or darker (dark shoe / shadow);
    # dark blobs are sorted into shoe vs shadow just below
    lighter=(Lff>np.maximum(PLv+8,PLv*1.15))                  # grey shoe: lighter than the empty volume
    cand=(dist>T)&darkP&lighter
    if 375<=j<=485:
        # the dark left shoe resting on the volume: any change, but only inside a box drawn tight around that shoe
        box=np.zeros((H,W),bool); box[350:383,244:284]=True
        cand|=box&(dist>T)&darkP&(Lff>PLv*0.25)
    # elsewhere (wall, yellow, green): normal foreground the model agrees is you; never the dome's own yellow
    fl=cv2.cvtColor(f,cv2.COLOR_BGR2LAB).astype(np.float32); fa,fb=fl[...,1]-128,fl[...,2]-128; fc=np.hypot(fa,fb)
    cosv=(fa*_pa+fb*_pb)/(fc*_pc+1e-3)
    domeish=(_pc>25)&(fc>22)&(cosv>0.9)
    cand|=(dist>9)&(p>0.5)&~darkP&~domeish
    g=m.astype(np.uint8); al=(cand|m).astype(np.uint8)
    for _ in range(steps): g=cv2.dilate(g,K3)&al
    g=cv2.morphologyEx(g,cv2.MORPH_OPEN,np.ones((2,2),np.uint8))
    g=(g>0)&~domeish
    # the leg's shadow on the black volume is much darker than the empty volume; the shoe is lighter.
    # remove small dark-on-volume blobs (shadow under the heel); the shorts are one large dark patch and stay
    D=(g&darkP&(Lf.astype(np.float32)<PLv*0.8)).astype(np.uint8)
    nD,lD,sD,_=cv2.connectedComponentsWithStats(D)
    ratio=Lf.astype(np.float32)/(PLv+1)
    for q in range(1,nD):
        # blob-level: the heel shadow sits around 0.3x the volume's brightness, a dark shoe around 0.55x
        inbox=(375<=j<=485) and (lD==q)[350:383,244:284].sum()>0.6*sD[q,4]
        if sD[q,4]<600 and np.median(ratio[lD==q])<0.42 and not inbox: g[lD==q]=False
    nG,lG,sG,_=cv2.connectedComponentsWithStats(g.astype(np.uint8))
    g=np.isin(lG,[k for k in range(1,nG) if sG[k,4]>=25])
    return f,g[y0:y1,x0:x1]>0
if __name__=='__main__':
    T=float(sys.argv[1]) if len(sys.argv)>1 else 7
    Mo=np.unpackbits(np.load('mask_local.npy'),axis=2)[:,:,:W].astype(bool)
    rows=[]; js=[300,332,348,380,412,428,460,492,524,540,556,572]
    for r in range(0,len(js),4):
        tiles=[]
        for j in js[r:r+4]:
            f,g=volume_mask(j,T)
            c=f[y0:y1,x0:x1]
            def ov(mm):
                o=np.full_like(c,255); o[mm]=(c[mm]*0.5+np.array([0,0,255])*0.5).astype(np.uint8); return o
            t=np.hstack([c,ov(Mo[j,y0:y1,x0:x1]),ov(g)]); cv2.putText(t,str(j),(3,14),cv2.FONT_HERSHEY_SIMPLEX,0.45,(255,0,0),1)
            tiles.append(cv2.copyMakeBorder(t,0,3,0,3,cv2.BORDER_CONSTANT,value=(128,128,128)))
        rows.append(np.hstack(tiles))
    cv2.imwrite('volfix.jpg',cv2.resize(np.vstack(rows),None,fx=0.75,fy=0.75))
