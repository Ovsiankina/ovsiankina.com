import sys; exec(open('objx.py').read().split("names=[n for n")[0]); exec("def _():pass")
src=open('objx.py').read(); exec(src[src.index('def catmull_clark'):])
import numpy as np, struct, json
LV=int(sys.argv[1])
seq=['b1','o1','u1','l','d1','e1','r','i','n1','g1']
x=0; parts=[]; gap=0.35
for s in seq:
    P,T=glyph(f'pilowlava_{s}_for_sds',LV)
    P=P.copy(); P[:,0]-=P[:,0].min(); P[:,0]+=x; x=P[:,0].max()+gap
    parts.append((P,T))
allP=[];allT=[];off=0;ranges=[]
for P,T in parts:
    allP.append(P); allT.append(T+off); ranges.append([int(sum(len(t) for t in allT[:-1])*3), int(len(T)*3)]); off+=len(P)
P=np.vstack(allP).astype(np.float32); T=np.vstack(allT).astype(np.uint32)
c=(P.min(0)+P.max(0))/2; P-=c
print('verts',len(P),'tris',len(T),'bounds',P.min(0),P.max(0))
hdr=json.dumps({'nv':len(P),'nt':len(T),'ranges':ranges}).encode(); hdr+=b' '*((4-len(hdr)%4)%4)
with open(f'title_l{LV}.bin','wb') as f:
    f.write(struct.pack('<I',len(hdr))); f.write(hdr); f.write(P.tobytes()); f.write(T.astype(np.uint16 if len(P)<65536 else np.uint32).tobytes())
