import cv2, numpy as np, sys
sys.argv=['x']; exec(open('seg3.py').read().split("if __name__")[0])
plab=cv2.cvtColor(plate,cv2.COLOR_BGR2LAB).astype(np.float32)
PL=plab[...,0]; PC=np.hypot(plab[...,1]-128,plab[...,2]-128)
wallP=(PL>150)&(PC<15); darkP=(PL<120)&(PC<14)   # black volumes only, not dark coloured holds
F=np.load('mask_final.npy'); P=np.load('ml_prob.npy',mmap_mode='r')
I0=100; N=F.shape[0]
out=np.zeros_like(F)
K3=np.ones((3,3),np.uint8)
def geo(seed,allowed,steps):
    g=seed.astype(np.uint8); al=allowed.astype(np.uint8)
    for _ in range(steps): g=cv2.dilate(g,K3)&(al|g)
    return g>0
for j in range(N):
    m=np.unpackbits(F[j],axis=1)[:,:W].astype(bool)
    if m.sum()<100: out[j]=F[j]; continue
    f,_,dist=seg(j+I0)
    Lf=cv2.cvtColor(f,cv2.COLOR_BGR2LAB)[...,0].astype(np.float32)
    p=cv2.resize(P[j],(W,H),interpolation=cv2.INTER_LINEAR).astype(np.float32)/255
    ys,xs=np.nonzero(m); top,bot=ys.min(),ys.max()
    feet=np.zeros((H,W),bool); feet[int(top+0.5*(bot-top)):min(H,bot+40),:]=True
    near=cv2.dilate(m.astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(61,61)))>0
    # shoes on black volumes: grow from shoe pixels already found, through dark pixels the model calls person
    seeds=m&(Lf<110)&feet
    fch=np.hypot(*(cv2.cvtColor(f,cv2.COLOR_BGR2LAB)[...,1:].astype(np.float32)-128).transpose(2,0,1))
    addV=geo(seeds,(p>0.7)&(Lf<130)&(fch<14)&darkP&feet&near,9)&~m
    # grey shoes on the white wall: anything the model calls person that also differs from the empty wall
    addW=geo(m,(p>0.75)&(dist>5)&wallP&feet&near,25)&~m
    fin=m|addV|addW
    fin=cv2.morphologyEx(fin.astype(np.uint8),cv2.MORPH_CLOSE,K3)>0
    out[j]=np.packbits(fin,axis=1)
    if j%200==0: print(j,int(addV.sum()),int(addW.sum()),flush=True)
np.save('mask_ml.npy',out)
