import base64, os, sys, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build
engine = open(os.path.join(HERE, 'engine.js')).read()
out, assets = sys.argv[1], sys.argv[2]
os.makedirs(os.path.join(out, 'folder', 'assets'), exist_ok=True)

def page(urls_js, inline_assets):
    body = build.markup(1440, 900, False, {'webm': '', 'mp4': ''})
    # full-viewport stage instead of a fixed artboard
    body = body.replace('width: 1440px; height: 900px; overflow: hidden', 'width: 100vw; height: 100vh; height: 100dvh; overflow: hidden', 1)
    body = re.sub(r'<section style="height: 900px;', '<section style="height: 100dvh;', body, count=1)
    body = body.replace('height: 540px; display: flex', 'height: 60dvh; display: flex', 1)
    body = body.replace('font-size: 64px', 'font-size: clamp(40px, 6vw, 64px)').replace('padding: 0 96px', 'padding: 0 max(20px, 7vw)')
    body = re.sub(r'<source[^>]*></source>\n', '', body)
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Climbing transition</title>
{build.FONTS}
<style>html,body{{margin:0;background:#08170F;overflow:hidden}}</style>
</head><body>
{body}
{inline_assets}
<script>
{engine}
(async () => {{
  const $ = id => document.getElementById(id);
  const urls = await ({urls_js})();
  const v = $('refVideo');
  v.src = v.canPlayType('video/webm; codecs="vp9"') ? urls.webm : urls.mp4;
  const fx = climbEngine({{
    stage: $('refStage'), scroller: $('refScroller'), fx: $('refFx'), fish: $('refFish'), holds: $('refHolds'),
    ascii: $('refAscii'), title: $('refTitle'), video: v,
    urls: {{ holds: urls.holds, mesh: urls.mesh }},
    opts: {{ speed: 1.5, blue: '#1238FF', ink: '#1B0D2E' }},
    startAt: location.hash === '#climb' ? 'climb' : 'page',
    setPhase: p => {{ $('refScroller').style.display = p === 'page' ? 'block' : 'none'; $('refScroller').nextElementSibling.style.display = p === 'climb' ? 'block' : 'none'; }},
  }});
  document.addEventListener('click', e => {{ const b = e.target.closest('[data-act]'); if (b) fx[b.dataset.act](); }});
}})();
</script>
</body></html>'''

# 1) folder version: html + assets/
import shutil
for f in ['holds_pack.png', 'climber.mp4', 'climber.webm', 'title_mesh.json']:
    shutil.copy(os.path.join(assets, f), os.path.join(out, 'folder', 'assets', f))
folder_urls = "async () => ({ holds: 'assets/holds_pack.png', mesh: 'assets/title_mesh.json', webm: 'assets/climber.webm', mp4: 'assets/climber.mp4' })"
open(os.path.join(out, 'folder', 'climbing.html'), 'w').write(page(folder_urls, ''))

# 2) single file: assets inlined as base64, turned into blob URLs at load
def b64(f): return base64.b64encode(open(os.path.join(assets, f), 'rb').read()).decode()
inline = '<script id="assets" type="application/json">{' + ','.join(
    f'"{k}":["{mime}","{b64(f)}"]' for k, f, mime in [
        ('holds', 'holds_pack.png', 'image/png'), ('mesh', 'title_mesh.json', 'application/json'),
        ('webm', 'climber.webm', 'video/webm'), ('mp4', 'climber.mp4', 'video/mp4')]) + '}</script>'
single_urls = """async () => {
  const A = JSON.parse(document.getElementById('assets').textContent), o = {};
  for (const k in A) { const bin = atob(A[k][1]), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    o[k] = URL.createObjectURL(new Blob([u], { type: A[k][0] })); }
  return o; }"""
open(os.path.join(out, 'climbing-transition.html'), 'w').write(page(single_urls, inline))
