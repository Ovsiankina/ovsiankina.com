import cv2, numpy as np, subprocess
from scipy.ndimage import median_filter
W,H=960,540; N=1650; I0,I1=100,1597
fr=np.memmap('frames960.raw',dtype=np.uint8,mode='r',shape=(N,H,W,3))
A=np.load('affines.npy'); A=median_filter(A,size=(5,1,1),mode='nearest')
M=np.load('mask_vol.npy')
OW,OH=640,360
cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','bgr24','-s',f'{OW}x{OH}','-r','30','-i','-','-c:v','libx264','-crf','26','-preset','slow','-pix_fmt','yuv420p','-movflags','+faststart','climber.mp4']
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for j,i in enumerate(range(I0,I1)):
    f=cv2.warpAffine(np.asarray(fr[i]),A[i],(W,H),borderMode=cv2.BORDER_REPLICATE)
    m=np.unpackbits(M[j],axis=1)[:,:W].astype(bool)
    o=f.copy(); o[~m]=255
    p.stdin.write(cv2.resize(o,(OW,OH),interpolation=cv2.INTER_AREA).tobytes())
p.stdin.close(); p.wait()
