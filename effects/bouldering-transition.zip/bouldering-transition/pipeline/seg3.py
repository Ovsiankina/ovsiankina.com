import cv2, numpy as np
from scipy.ndimage import median_filter
W,H=960,540; N=1650
fr=np.memmap('frames960.raw',dtype=np.uint8,mode='r',shape=(N,H,W,3))
A=np.load('affines.npy'); A=median_filter(A,size=(5,1,1),mode='nearest')
def align(i): return cv2.warpAffine(np.asarray(fr[i]),A[i],(W,H),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE)
plate=np.median(np.stack([align(i) for i in range(60,96,2)]),0).astype(np.uint8)
cv2.imwrite('plate2.png',plate)
pl=cv2.GaussianBlur(cv2.cvtColor(plate,cv2.COLOR_BGR2LAB).astype(np.float32),(3,3),0)
R=2
shifted=[np.roll(np.roll(pl,dy,0),dx,1) for dy in range(-R,R+1) for dx in range(-R,R+1)]
roi=np.zeros((H,W),np.uint8); roi[:,:]=1
def seg(i, thr=16):
    f=align(i)
    lab=cv2.GaussianBlur(cv2.cvtColor(f,cv2.COLOR_BGR2LAB).astype(np.float32),(3,3),0)
    dist=None
    for p in shifted:
        d=lab-p; x=(d[...,0]*0.45)**2+(d[...,1]**2+d[...,2]**2)*2.0
        dist=x if dist is None else np.minimum(dist,x)
    dist=np.sqrt(dist)
    m=(dist>thr).astype(np.uint8)
    m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((2,2),np.uint8))
    m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(11,11)))
    n,lbl,st,_=cv2.connectedComponentsWithStats(m)
    keep=np.zeros_like(m)
    if n>1:
        big=1+np.argmax(st[1:,4]); bx,by,bw,bh,ba=st[big]
        if ba>150:
          for k in range(1,n):
            x,y,w,h,a=st[k]
            if k==big or (a>80 and x<bx+bw+25 and x+w>bx-25 and y<by+bh+25 and y+h>by-25): keep[lbl==k]=1
    ff=keep.copy(); cv2.floodFill(ff,np.zeros((H+2,W+2),np.uint8),(0,0),1)
    keep=keep|(1-ff)
    return f,keep,dist
if __name__=='__main__':
    tiles=[]
    for t in [5,9,14,20,30,40,48,52]:
        i=int(t*30); f,m,dist=seg(i)
        o=f.copy(); o[m==0]=255
        g=cv2.cvtColor(np.clip(dist*4,0,255).astype(np.uint8),cv2.COLOR_GRAY2BGR)
        tiles.append(np.hstack([cv2.resize(o,(480,270)),cv2.resize(g,(480,270))]))
    cv2.imwrite('segtest2.jpg',np.vstack(tiles))
