import cv2, numpy as np, sys
sys.argv=['x']; exec(open('seg3.py').read().split("if __name__")[0])
plab=cv2.cvtColor(plate,cv2.COLOR_BGR2LAB).astype(np.float32)
pchroma=np.hypot(plab[...,1]-128,plab[...,2]-128)
I0,I1=100,1597
N=I1-I0
old=np.zeros((N,H,W//8),np.uint8); new=np.zeros((N,H,W//8),np.uint8)
def shadow_of(f):
    lab=cv2.cvtColor(f,cv2.COLOR_BGR2LAB).astype(np.float32)
    ratio=(lab[...,0]+1)/(plab[...,0]+1)
    dch=np.hypot(lab[...,1]-plab[...,1],lab[...,2]-plab[...,2])
    sh=(ratio>0.5)&(ratio<0.97)&(dch<7)&(pchroma<12)
    fa,fb=lab[...,1]-128,lab[...,2]-128; pa,pb=plab[...,1]-128,plab[...,2]-128
    fc=np.hypot(fa,fb); cosang=(fa*pa+fb*pb)/(fc*pchroma+1e-3)
    sh|=(pchroma>=12)&(ratio>0.35)&(ratio<0.98)&(cosang>0.96)&(fc/(pchroma+1e-3)>0.45)&(fc/(pchroma+1e-3)<1.15)
    return sh, lab
def fill(m):
    ff=m.copy(); cv2.floodFill(ff,np.zeros((H+2,W+2),np.uint8),(0,0),1); return m|(1-ff)
prev=None; prevlab=None; age=np.zeros((H,W),np.uint8)
K7=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(7,7)); K25=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(41,41))
for j,i in enumerate(range(I0,I1)):
    f,m,dist=seg(i)
    sh,lab=shadow_of(f)
    # ---- old
    m2=(m.astype(bool)&~sh).astype(np.uint8)
    m2=cv2.morphologyEx(m2,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
    n,lbl,st,_=cv2.connectedComponentsWithStats(m2)
    keep=np.isin(lbl,[k for k in range(1,n) if st[k,4]>=max(40,st[1+np.argmax(st[1:,4]),4]*0.03)]) if n>1 else np.zeros_like(m2,bool)
    old[j]=np.packbits(keep,axis=1)
    # ---- new: core from the strong mask, hysteresis growth through the weak mask
    core=(m.astype(bool)&~sh).astype(np.uint8)
    weak=((dist>9)&~sh).astype(np.uint8)
    weak=cv2.morphologyEx(weak|core,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
    n,lbl,st,_=cv2.connectedComponentsWithStats(weak)
    if core.sum()>150 and n>1:
        near=cv2.dilate(core,K7)
        hit=np.unique(lbl[(near>0)&(weak>0)]); hit=hit[hit>0]
        fin=np.isin(lbl,hit).astype(np.uint8)
        # drop specks that are far from the body
        n2,l2,s2,_=cv2.connectedComponentsWithStats(fin)
        big=1+np.argmax(s2[1:,4]); body=(l2==big).astype(np.uint8); bodyd=cv2.dilate(body,K25)
        keepids=[k for k in range(1,n2) if k==big or (s2[k,4]>=20 and bodyd[l2==k].any())]
        fin=np.isin(l2,keepids).astype(np.uint8)
        # temporal persistence: a limb resting on a same-coloured hold stops differing from the plate,
        # but it also stops changing between frames, so carry it over (briefly, and only near the body)
        if prev is not None:
            still=np.sqrt(((lab-prevlab)**2).sum(-1))<7
            carry=(prev>0)&(fin==0)&still&(bodyd>0)&(age<15)
            age=np.where(carry,age+1,0).astype(np.uint8)
            fin=fin|carry.astype(np.uint8)
        fin=fill(cv2.morphologyEx(fin,cv2.MORPH_OPEN,np.ones((2,2),np.uint8)))
    else:
        fin=np.zeros((H,W),np.uint8); age[:]=0
    new[j]=np.packbits(fin.astype(bool),axis=1)
    prev=fin; prevlab=lab
    if j%300==0: print(j,flush=True)
np.save('mask_old.npy',old); np.save('mask_new.npy',new)
