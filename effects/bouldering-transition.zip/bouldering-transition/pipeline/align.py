import cv2, numpy as np
W,H=960,540; N=1650
fr=np.memmap('frames960.raw',dtype=np.uint8,mode='r',shape=(N,H,W,3))
plate=cv2.imread('plate.png'); pg=cv2.cvtColor(plate,cv2.COLOR_BGR2GRAY)
orb=cv2.ORB_create(3000)
mask=np.zeros((H,W),np.uint8); mask[:465,:870]=255
kp0,d0=orb.detectAndCompute(pg,mask)
bf=cv2.BFMatcher(cv2.NORM_HAMMING,crossCheck=True)
Ms=[]
for i in range(N):
    g=cv2.cvtColor(np.asarray(fr[i]),cv2.COLOR_BGR2GRAY)
    kp,d=orb.detectAndCompute(g,mask)
    m=bf.match(d,d0)
    src=np.float32([kp[x.queryIdx].pt for x in m]); dst=np.float32([kp0[x.trainIdx].pt for x in m])
    M,inl=cv2.estimateAffinePartial2D(src,dst,method=cv2.RANSAC,ransacReprojThreshold=1.5)
    Ms.append(M)
    if i%60==0: print(i/30, np.round(M,4).tolist(), int(inl.sum()))
np.save('affines.npy',np.array(Ms))
