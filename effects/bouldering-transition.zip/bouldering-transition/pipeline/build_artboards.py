import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
engine = open(os.path.join(HERE, 'engine.js')).read()

BLOB = {
    'holds': '/_blob/eb305bc36ac57a9ed895aae0d8692cdb',
    'mp4': '/_blob/1fe080ae46edca432db31ca952bd18fc',
    'webm': '/_blob/f18716b6ff4c5d18d91ec40b63f077a7',
    'mesh': '/_blob/087bd6a98a6d21d32776652cd5b77a37',
}
LOCAL = {'holds': 'holds_pack.png', 'mp4': 'climber.mp4', 'webm': 'climber.webm', 'mesh': 'title_mesh.json'}

FONTS = '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&amp;family=Space+Grotesk:wght@400;500&amp;display=swap">'

def markup(W, H, dc, urls):
    phone = W < 700
    qsize = 40 if phone else 64
    pad = 20 if phone else 96
    def h(name, fallback):
        return '{{%s}}' % name if dc else fallback
    def ref(name):
        return ' ref="{{%s}}"' % name if dc else ' id="%s"' % name
    def on(evt, name):
        return ' %s="{{%s}}"' % (evt, name) if dc else ' data-act="%s"' % name
    mono = "font-family: 'JetBrains Mono', ui-monospace, monospace"
    sans = "font-family: 'Space Grotesk', system-ui, sans-serif"
    pill = f"min-height: 44px; padding: 0 20px; border-radius: 22px; font-size: 13px; {mono}; cursor: pointer; background: transparent"
    canvas = "position: absolute; left: 0; top: 0; image-rendering: pixelated"
    return f'''<div{ref('refStage')} style="position: relative; width: {W}px; height: {H}px; overflow: hidden; background: #FFFFFF">
<div{ref('refScroller')} style="position: absolute; left: 0; top: 0; width: 100%; height: 100%; overflow-y: auto; background: #08170F; color: #DCEBDF; display: {h('pageDisplay', 'block')}">
<section style="height: {H}px; box-sizing: border-box; padding: 0 {pad}px; display: flex; flex-direction: column; justify-content: center; gap: 24px">
<p style="margin: 0; {mono}; font-size: 13px; letter-spacing: 0.08em; text-transform: uppercase; color: #7FC69A">next</p>
<h2 style="margin: 0; {sans}; font-weight: 500; font-size: {qsize}px; line-height: 1.05; letter-spacing: -0.02em">{h('question', 'Ready to climb up?')}</h2>
<div style="display: flex; flex-wrap: wrap; gap: 16px; align-items: center">
<button type="button"{on('onClick', 'climb')} style="{pill}; color: #DCEBDF; border: 1px solid #2F5A40">climb ↑</button>
<span style="{mono}; font-size: 13px; color: #5E8C70">or scroll ↓</span>
</div>
</section>
<section style="height: {int(H * 0.6)}px; display: flex; align-items: center; justify-content: center">
<span style="{mono}; font-size: 13px; letter-spacing: 0.3em; color: #2F5A40">↓ ↓ ↓</span>
</section>
</div>
<div style="position: absolute; left: 0; top: 0; width: 100%; height: 100%; background: #FFFFFF; display: {h('climbDisplay', 'none')}">
<canvas{ref('refHolds')} aria-hidden="true" style="{canvas}"></canvas>
<canvas{ref('refAscii')} aria-hidden="true" style="position: absolute; left: 0; top: 0"></canvas>
<canvas{ref('refTitle')} role="img" aria-label="Bouldering" style="{canvas}"></canvas>
<div style="position: absolute; left: {20 if phone else 32}px; bottom: {20 if phone else 32}px; display: flex; gap: 12px">
<button type="button"{on('onClick', 'replay')} style="{pill}; color: #1B0D2E; background: #FFFFFF; border: 1px solid #C9C2D4">replay</button>
<button type="button"{on('onClick', 'back')} style="{pill}; color: #1B0D2E; background: #FFFFFF; border: 1px solid #C9C2D4">back</button>
</div>
</div>
<canvas{ref('refFx')} aria-hidden="true" style="{canvas}; pointer-events: none"></canvas>
<canvas{ref('refFish')} aria-hidden="true" style="position: absolute; left: 0; top: 0; pointer-events: none"></canvas>
<video{ref('refVideo')} muted="{{yes}}" preload="auto" aria-hidden="true" style="position: absolute; left: 0; top: 0; width: 2px; height: 2px; opacity: 0; pointer-events: none">
<source src="{urls['webm']}" type="video/webm">
<source src="{urls['mp4']}" type="video/mp4">
</video>
</div>'''.replace('muted="{{yes}}"', 'muted="{{yes}}"' if dc else 'muted')

def dc_file(W, H, title):
    props = {
        "question": {"editor": "enum", "options": ["Ready to climb up?", "Ready to go higher?"], "default": "Ready to climb up?"},
        "speed": {"editor": "range", "min": 0.5, "max": 3, "step": 0.1, "default": 1.5, "unit": "×"},
        "blue": {"editor": "color", "options": ["#1238FF", "#0A1BFF", "#2B4BFF"], "default": "#1238FF"},
        "startAt": {"editor": "enum", "options": ["page", "climb"], "default": "page"},
        "$preview": {"width": W, "height": H},
    }
    body = markup(W, H, True, BLOB)
    script = '''class Component extends DCLogic {
renderVals() {
if (!this._r) {
this._r = {};
for (const k of ['Stage', 'Scroller', 'Holds', 'Ascii', 'Title', 'Fx', 'Fish', 'Video']) this._r['ref' + k] = (el) => { this['el' + k] = el; };
}
const phase = (this.state && this.state.phase) || 'page';
return Object.assign({}, this._r, {
yes: true,
question: this.props.question ?? 'Ready to climb up?',
pageDisplay: phase === 'page' ? 'block' : 'none',
climbDisplay: phase === 'climb' ? 'block' : 'none',
climb: () => this.fx && this.fx.climb(),
replay: () => this.fx && this.fx.replay(),
back: () => this.fx && this.fx.back(),
});
}
componentDidMount() {
const go = () => {
if (!this.elStage || !this.elFx || !this.elVideo) { this._t = setTimeout(go, 50); return; }
this.fx = this.makeEngine({
stage: this.elStage, scroller: this.elScroller, fx: this.elFx, fish: this.elFish,
holds: this.elHolds, ascii: this.elAscii, title: this.elTitle, video: this.elVideo,
urls: { holds: '%s', mesh: '%s' },
opts: { speed: this.props.speed ?? 1.5, blue: this.props.blue ?? '#1238FF', ink: '#1B0D2E' },
startAt: this.props.startAt ?? 'page',
setPhase: (p) => this.setState({ phase: p }),
});
};
go();
}
componentDidUpdate(prev) {
if (this.fx && (prev.speed !== this.props.speed || prev.blue !== this.props.blue || prev.startAt !== this.props.startAt)) {
this.fx.destroy(); this.fx = null; this.setState({ phase: 'page' }); this.componentDidMount();
}
}
componentWillUnmount() { clearTimeout(this._t); if (this.fx) this.fx.destroy(); }
makeEngine(E) {
%s
return climbEngine(E);
}
}''' % (BLOB['holds'], BLOB['mesh'], engine)
    return f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
{FONTS}
<style>
body{{margin:0}}
a{{color:#1238FF}}a:hover{{color:#0A1466}}
</style>
</helmet>
{body}
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{json.dumps(props, ensure_ascii=False)}'>
{script}
</script>
</body>
</html>
'''

def test_file(W, H, startAt):
    body = markup(W, H, False, LOCAL)
    return f'''<!doctype html><html><head><meta charset="utf-8">{FONTS}<style>body{{margin:0}}</style></head><body>
{body}
<script>
{engine}
const $ = id => document.getElementById(id);
window.fx = climbEngine({{
  stage: $('refStage'), scroller: $('refScroller'), fx: $('refFx'), fish: $('refFish'), holds: $('refHolds'), ascii: $('refAscii'), title: $('refTitle'), video: $('refVideo'),
  urls: {{ holds: '{LOCAL['holds']}', mesh: '{LOCAL['mesh']}' }},
  opts: {{ speed: 1.5, blue: '#1238FF', ink: '#1B0D2E' }},
  startAt: '{startAt}',
  setPhase: p => {{ $('refScroller').style.display = p === 'page' ? 'block' : 'none'; $('refScroller').nextElementSibling.style.display = p === 'climb' ? 'block' : 'none'; }},
}});
document.addEventListener('click', e => {{ const b = e.target.closest('[data-act]'); if (b) window.fx[b.dataset.act](); }});
</script></body></html>'''

if __name__ == '__main__':
    out = sys.argv[1]
    os.makedirs(os.path.join(out, 'project'), exist_ok=True)
    open(os.path.join(out, 'project', 'Main.dc.html'), 'w').write(dc_file(1440, 900, 'Climbing transition, desktop'))
    open(os.path.join(out, 'project', 'Phone.dc.html'), 'w').write(dc_file(390, 844, 'Climbing transition, phone'))
    tdir = sys.argv[2]
    open(os.path.join(tdir, 'test_desk.html'), 'w').write(test_file(1440, 900, 'page'))
    open(os.path.join(tdir, 'test_phone.html'), 'w').write(test_file(390, 844, 'page'))
