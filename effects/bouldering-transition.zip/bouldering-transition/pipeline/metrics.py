import numpy as np, cv2
W,H=960,540
def load(n): return np.unpackbits(np.load(n),axis=2)[:,:,:W].astype(bool)
def temporal(M):
    out=M.copy(); K=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(31,31))
    for t in range(2,len(M)-2):
        a=M[t-1]|M[t-2]; b=M[t+1]|M[t+2]
        near=cv2.dilate(M[t].astype(np.uint8),K)>0
        out[t]=M[t]|(a&b&near&(M[t-1]|M[t+1]))
    return out
def stats(M):
    low=np.array([np.nonzero(m.any(1))[0].max() if m.any() else 0 for m in M]); area=M.reshape(len(M),-1).sum(1)
    spikes=[t for t in range(1,len(M)-1) if low[t]<min(low[t-1],low[t+1])-10]
    dips=[t for t in range(1,len(M)-1) if area[t]<0.9*min(area[t-1],area[t+1])]
    return low,area,spikes,dips
O=load('mask_old.npy'); N=load('mask_new.npy'); NT=temporal(N)
np.save('mask_final.npy',np.packbits(NT,axis=2))
for name,M in [('old',O),('new',N),('new+temporal',NT)]:
    low,area,sp,dp=stats(M); print(name,'lowest-point spikes',len(sp),'area dips',len(dp), sp[:25])
